


8-Ch04 - Image Map


10-Ch05 - Site Map


14-Ch08 - Table - multiple rows and columns





20-Ch14 - Previous Page  - JavaScript


EXTRA CREDIT





Website Search Feature Ch09

Privacy Policy Ch09




Blog Ch01 & Ch13

Other things Ch01 - Ch14, Google, etc.






<audio controls="controls">
  <source src="audio.mp3" type="audio/mpeg">
  <source src="audio.ogg" type="audio/ogg">
  <a href="audio.m4a">Welcome to Atlanta House Cleaners</a>
</audio>