	//Form Validation
	function validateForm() {
		if (document.forms[0].txtName.value == "") {
			alert("Name field cannot be empty.");
			return false;
		}else if (document.forms[0].txtEmail.value == "") {
			alert("Email field cannot be empty.");
			return false;
		}else {
			return true;
		}
	}
	//Displays the date
	function displayDate(){
		var now = new Date();
		var days = new Array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
		var months = new Array('January','February','March','April','May','June','July','August','September','October','November','December');
		var date = ((now.getDate()<10) ? "0" : "")+ now.getDate();

		function fourdigits(number)	{
			return (number < 1000) ? number + 1900 : number;
		}
		today =  days[now.getDay()] + ", " +
        months[now.getMonth()] + " " + date + ", " +
    	(fourdigits(now.getYear())) ;
		document.write(today);
		}
	//Displays users IP address
	function displayIP(){
		var ip = '<!--#echo var="REMOTE_ADDR"-->';
		document.write("Your IP address is" + ip);
		}
	//Creates a dropdown menu
	function dropMenu(items, tags) {
 		tags = tags || ['ul', 'li']; // default tags
  		var parent = tags[0];
  		var child = tags[1];
 		var item, value = '';
  		
  		for (var i = 0, l = items.length; i < l; i++) {
    		item = items[i];
    		// Separate item and value if value is present
    		if (/:/.test(item)) {
      			item = items[i].split(':')[0];
      			value = items[i].split(':')[1];
    			}
    		// Wrap the item in tag
    		items[i] = '<'+ child +' '+ 
      		(value && 'value="'+value+'"') +'>'+ // add value if present
        	item +'</'+ child +'>';
  			}
 			return '<'+ parent +'>'+ items.join('') +'</'+ parent +'>';
				}
	//Preloads images
	function preloadImages(){
		var images = new Array();
    	for (i=0; i < preloadImages.arguments.length; i++){
			images[i] = new Image();
			images[i].src = preloadImages.arguments[i];
			}
		}
		